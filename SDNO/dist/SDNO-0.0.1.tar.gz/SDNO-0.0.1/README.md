# SDNO

SDNO is a smart democratization neural network optimizer.