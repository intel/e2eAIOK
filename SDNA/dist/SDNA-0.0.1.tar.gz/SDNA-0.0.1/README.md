# SDNA

SDNO is a smart democratization neural network advisor.